{
    "functions"= {
      "app/api/**/*": {
        "maxDuration": 180
      }
    }
}